Lista doblemente enlazada 
=========================

Escuela Superior Politécnica del Litoral
Version 1.0 15/08/2017 

# Lista_doblemente_enlazada

1 - Descripción
---------------

En este proyecto implementaremos una lista en enlazada especial como una librería dinámica (.so). La lista enlazada se comportará como una lista simple, pero internamente será implementada como una lista doblemente enlazada.

2 - Instalación
----------------

Para crear los ejecutables se disponible de una archivo makefile que le facilitará el trabajo.

```
make
```
3 - Modo de uso general
------------------------

* iniciar pruebalista.

```
./bin/prueba 5000
```	
el 5000 indica la cantidad de elementos con los que se realizara la prueba.Numero de elementos de la lista.

4 - Autores
-----------

* Leiton Mauricio
* Wong Hugo
* Zambrano Jhonny
